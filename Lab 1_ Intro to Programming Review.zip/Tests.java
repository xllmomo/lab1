/**
 * The main method of this class contains test cases for the Course class. The 
 * tests are similar to the hidden tests used to evaluate your code on zyLabs. 
 * If your code fails the zyLab tests, try writing additional tests here to 
 * find the problem.
 */
public class Tests
{
	public static void main(String[] args)
	{
		// Construct a Course object with information about our course.
		String info = "CS 2334,Programming Structures and Abstractions,148";
		Course course = new Course(info);

		// Test that getName() returns the course name.
		String name = course.getName();
		if (!name.equals("Programming Structures and Abstractions"))
		{
			System.out.println("getName() test failed");
		}
				
		// Test that getNumSections() returns the correct number of sections.
		int numSections = course.getNumSections();
		if (numSections != 3)
		{
			System.out.println("getNumSections() test failed");
		}
	}
}