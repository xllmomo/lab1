/**
 * Lab 1 template
 * CS 2334 Spring 2020
 */
public class Course
{
	private static final int MAX_SECTION_SIZE = 50;
	// TODO: Declare the field that stores the course code.
	// TODO: Declare the field that stores the course name.
	// TODO: Declare the field that stores the number of students.
	private int numSections;
	
	// The constructor should initialize all the instance (i.e., non-static) 
	// fields. Constructors often have a parameter list with one parameter per 
	// field. This constructor, however, takes a single String with the 
	// following information separated by commas:
	// 1. course code
	// 2. course name
	// 3. number of students
	// For example, to create an object that stores information about our 
	// course, we would pass the constructor the following String:
	//     "CS 2334,Programming Structures and Abstractions,148"
	// This String must be split into pieces and used to initialize the fields.
	public Course(String info)
	{
		// TODO: Split the info String into an array of three Strings where 
		// the first element is the course code, the second is the name, and 
		// the third is the number of students. The easiest way to do this is 
		// to use the split method of the String class. (See the String class 
		// API documentation.)
		
		// TODO: Initialize the field that stores the course code. This field 
		// is a reference to a String array of length 2. The first element is 
		// the subject abbreviation, and the second element is the course 
		// number. For example, if the course code is "CS 2334", then the 
		// course field should be the array {"CS", "2334"}. You may assume 
		// that the course code always consists of the subject abbreviation 
		// and the course number separated by a single space.
		
		// TODO: Initialize the field that stores the course name. The name is 
		// the second element of the split info String.
		
		// TODO: Initialize the field that stores the number of students. This 
		// number is the third element of the split info String. Note that the 
		// number must be converted to an int before it can be assigned to the 
		// field.
		
		// TODO: Initialize the field that stores the number of sections. Note 
		// that this number is not included in the info String; it must be 
		// calculated from the number of students.
		numSections = calcNumSections(0);  // TODO: Replace the argument.
	}
	
	// This is a helper method used by the constructor to calculate the number 
	// of sections from the number of students. Because it is static, it can 
	// only access static fields (i.e., MAX_SECTION_SIZE). In order to use the 
	// number of students in the calculation, the number must be passed to the 
	// method as a parameter, since the number of students field is non-static.
	private static int calcNumSections(int numStudents)
	{
		// TODO: Use the number of students and the maximum section size to 
		// calculate and return the number of sections.
		return 0;
	}
	
	public String[] getCode()
	{
		// TODO: Make a copy of the code field, which is an array of two 
		// Strings. Return the copy so the calling method cannot change the 
		// field.
		return null;
	}
	
	public String getName()
	{
		// TODO: Return the name of the course.
		return "Replace this String with the course name.";
	}
	
	public int getNumStudents()
	{
		// TODO: Return the number of students.
		return 0;
	}
	
	public int getNumSections()
	{
		return numSections;
	}
	
	public String toString()
	{
		// TODO: Return a String with all of the course information. The 
		// String needs to be formatted exactly as described in the 
		// instructions in order to pass the toString test case. For example, 
		// if the constructor is given a String with information about our 
		// course, then the following String should be returned:
		// "CODE: CS 2334, NAME: Programming Structures and Abstractions, STUDENTS: 148, SECTIONS: 3"
		return "Replace this String with the course information.";
	}
}